import { useEffect, useRef, useState } from 'react'
import type { SearchHit } from '@shared/types'
import { dirname } from '@shared/markdown-parse'
import { Icon } from './Icon'
import { PanelHeader } from './FileTree'
import { openNote } from '../lib/actions'
import { useUi } from '../store/uiStore'
import { useWorkspace } from '../store/workspaceStore'

export default function SearchPanel(): React.JSX.Element {
  const query = useUi((s) => s.searchQuery)
  const setQuery = useUi((s) => s.setSearchQuery)
  const [hits, setHits] = useState<SearchHit[]>([])
  const [searching, setSearching] = useState(false)
  const [titleOnly, setTitleOnly] = useState(false)
  const [scoped, setScoped] = useState(false)
  const input = useRef<HTMLInputElement>(null)
  const leftPanel = useWorkspace((s) => s.leftPanel)
  const activeNotePath = useWorkspace((s) => s.tabs[s.activeTab]?.path)
  const currentFolder = activeNotePath ? dirname(activeNotePath) : ''

  useEffect(() => {
    if (leftPanel === 'search') input.current?.focus()
  }, [leftPanel])

  useEffect(() => {
    const q = query.trim()
    if (!q) {
      setHits([])
      setSearching(false)
      return
    }
    setSearching(true)
    let cancelled = false
    // Debounced so a fast typist does not queue a search per keystroke.
    const timer = setTimeout(() => {
      void window.lumina.search
        .query(q, {
          titleOnly,
          folder: scoped && currentFolder ? currentFolder : undefined
        })
        .then((results) => {
          if (!cancelled) setHits(results)
        })
        .catch(() => {
          if (!cancelled) setHits([])
        })
        .finally(() => {
          if (!cancelled) setSearching(false)
        })
    }, 160)
    return () => {
      cancelled = true
      clearTimeout(timer)
    }
  }, [query, titleOnly, scoped, currentFolder])

  const totalMatches = hits.reduce((sum, h) => sum + Math.max(1, h.matches.length), 0)

  return (
    <>
      <PanelHeader title="Search"
        actions={
          query ? (
            <button className="icon-btn" title="Clear" onClick={() => setQuery('')}>
              <Icon name="close" size={14} />
            </button>
          ) : null
        }
      />

      <div className="search-box">
        <Icon name="search" size={14} />
        <input
          ref={input}
          type="search"
          value={query}
          spellCheck={false}
          placeholder="Search notes…"
          onChange={(e) => setQuery(e.target.value)}
        />
      </div>

      <div className="search-filters">
        <button
          className={`search-filter${titleOnly ? ' on' : ''}`}
          data-tooltip="Match note titles only"
          onClick={() => setTitleOnly((v) => !v)}
        >
          Titles only
        </button>
        <button
          className={`search-filter${scoped ? ' on' : ''}`}
          data-tooltip={currentFolder ? `Scope to ${currentFolder}` : 'Open a note to scope to its folder'}
          disabled={!currentFolder}
          onClick={() => setScoped((v) => !v)}
        >
          This folder
        </button>
      </div>

      {query.trim() ? (
        <div className="search-meta">
          {searching
            ? 'Searching…'
            : hits.length
              ? `${totalMatches} match${totalMatches === 1 ? '' : 'es'} in ${hits.length} note${hits.length === 1 ? '' : 's'}`
              : 'No matches'}
        </div>
      ) : null}

      <div className="panel-scroll">
        {hits.map((hit) => (
          <div key={hit.path} className="search-hit">
            <button className="search-hit-title truncate" data-tooltip="Open note" onClick={() => openNote(hit.path)}>
              {hit.title}
            </button>
            {hit.matches.map((m, i) => (
              <button
                key={`${m.line}-${i}`}
                className="search-hit-line"
                data-tooltip="Go to match"
                onClick={() => openNote(hit.path, { line: m.line })}
              >
                <span className="search-hit-lineno">{m.line + 1}</span>
                <span className="search-hit-text">
                  {m.text.slice(0, m.from)}
                  <mark>{m.text.slice(m.from, m.to)}</mark>
                  {m.text.slice(m.to)}
                </span>
              </button>
            ))}
          </div>
        ))}
        {!query.trim() ? (
          <div className="empty-state empty-state-panel">
            <Icon name="search" size={22} />
            <h2>Search your vault</h2>
            <p>Wrap a phrase in quotes to match it exactly.</p>
          </div>
        ) : !searching && !hits.length ? (
          <div className="empty-state empty-state-panel">
            <Icon name="search" size={22} />
            <h2>No matches</h2>
            <p>Nothing in this vault matches “{query.trim()}”.</p>
          </div>
        ) : null}
      </div>
    </>
  )
}
