/**
 * Naming for notes taken through the OS-wide shortcut.
 *
 * Pure and shared so `tests/quick-note.test.ts` can cover it: the format has
 * to stay filesystem-safe on Windows, where a colon is not a legal filename
 * character — which rules out the obvious `HH:mm`.
 */
import { formatDate } from './template'

export const DEFAULT_QUICK_NOTE_FOLDER = 'Temporary'

/** A quick note's title: sortable, unique to the second, safe on every platform. */
export function quickNoteName(date = new Date()): string {
  return `Note ${formatDate('YYYY-MM-DD HH-mm-ss', date)}`
}
